import React from 'react'
import './testimonials.css'

const Testimonials = () => {
  return (
    <section id='testimonials'>Testimonials</section>
  )
}

export default Testimonials