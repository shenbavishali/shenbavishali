import React from 'react'
import './about.css'

const About = () => {
  return (
    <section id='about'>About</section>
  )
}

export default About