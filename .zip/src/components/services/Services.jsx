import React from 'react'
import './services.css'

const Services = () => {
  return (
    <section id='services'>Services</section>
  )
}

export default Services