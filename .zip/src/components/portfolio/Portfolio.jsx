import React from 'react'
import './portfolio.css'

const Portfolio = () => {
  return (
    <section id='portfolio'>Portfolio</section>
  )
}

export default Portfolio