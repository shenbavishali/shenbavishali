import React from 'react'
import './experience.css'

const Experience = () => {
  return (
    <section id='experience'>Experience</section>
  )
}

export default Experience